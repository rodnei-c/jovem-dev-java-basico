package avaliacao;

import java.util.ArrayList;

public class Medicamento {
	String nome;
	ArrayList<Integer> ativos = new ArrayList<>();
}
