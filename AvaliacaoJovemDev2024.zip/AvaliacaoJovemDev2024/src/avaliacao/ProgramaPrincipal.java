package avaliacao;

import java.util.ArrayList;

import javax.swing.JOptionPane;

public class ProgramaPrincipal {
	
	/*
	 *  	Um medicamento, além do nome comercial, tem os nomes dos princípios ativos que o compõe.

			Por exemplo, o medicamento CIMEGRIPE é composto por:
			- PARACETAMOL,
			- CLORFENIRAMINA 
			- FENILEFRINA.
			Já o medicamento TYLENOL é composto por 
			- PARACETAMOL
			
			Desta forma, um medicamento pode ter um ou vários princípios ativos e um princípio ativo pode ser utilizado em vários medicamentos.
			
			Pede-se um programa que possibilite o cadastro de medicamentos com os seguintes requisitos:
			
			a.	Utilize Registro para representar cada medicamento
			b.	Utilize sub-rotinas para realizar as operações solicitadas.
			c.	Utilize ArrayList para armazenar os medicamentos
			d.	Restrinja a inclusão de no máximo 500 medicamentos 
			
			O programa deve exibir um menu com as seguintes opções:
			
			1 – Incluir medicamento {fazer o cadastro do medicamento em memória}
			2 – Listar todos os medicamentos { listar todos os medicamentos cadastrados cada qual com os respectivos princípios ativos}
			3 – Buscar por nome de princípio ativo {usuário digita o nome de um princípio ativo e o programa mostra todos os medicamentos que contém aquele o princípio ativo}
			4 – Mostrar o percentual de memória livre {o programa deve mostrar em PERCENTUAL a quantidade disponível para cadastro}
			0 – Sair do sistema

	 */

	public static void main(String[] args) {
		ArrayList <Medicamento> medicamentos = new ArrayList<>();
		
		int op = -1;
		
		do {
			
			op = menu();
			
			switch(op) {
			case 1:
				cadastrar(medicamentos);
				break;
			case 2:
				JOptionPane.showMessageDialog(null, listarMedicamentos(medicamentos));
				break;
			case 3:
				JOptionPane.showMessageDialog(null, buscarPorAtivo(medicamentos));
				break;
			case 4:
				JOptionPane.showMessageDialog(null, "Tem " + memoria(medicamentos) + "% de memória livre.");
				break;
			}
			
		} while(op != 0);
		
		
	}
	
	public static double memoria(ArrayList<Medicamento> medicamentos) {
		
		double sub = (double) medicamentos.size() / 500 * 100;
		double percentual = 100 - sub;
		
		return percentual;
		
	}
	
	public static String buscarPorAtivo(ArrayList<Medicamento> medicamentos) {
		
		int atBusca = Integer.parseInt(JOptionPane.showInputDialog("Por qual ativo deseja buscar? \n"
				+ "1 - PARACETAMOL\n"
				+ "2 - CLORFENIRAMINA\n"
				+ "3 - FENILEFRINA\n"));
		String msg = "";
		if(atBusca == 1) {
		
		for (Medicamento medicamento : medicamentos) {
			if(ativos(medicamento).contains("PARACETAMOL")) {
				msg += medicamento.nome + "\n";
			} 
		}
		return "Lista de medicamentos com o ativo PARACETAMOL: \n" + msg;
		}
		if(atBusca == 2) {
			msg = "Lista de medicamentos com o ativo CLORFENIRAMINA: \n";
			for (Medicamento medicamento : medicamentos) {
				if(ativos(medicamento).contains("CLORFENIRAMINA")) {
					msg += medicamento.nome + "\n";
				} 
			}
		return "Lista de medicamentos com o ativo CLORFENIRAMINA: \n" + msg;
		}
		if(atBusca == 3) {
			msg = "Lista de medicamentos com o ativo FENILEFRINA: \n";
			for (Medicamento medicamento : medicamentos) {
				if(ativos(medicamento).contains("FENILEFRINA")) {
					msg += medicamento.nome + "\n";
				} 
			}
		return "Lista de medicamentos com o ativo FENILEFRINA: \n" + msg;
		}
		return buscarPorAtivo(medicamentos);
		
	}
	
	public static String listarMedicamentos(ArrayList<Medicamento> medicamentos) {
		String msg = "Lista de medicamentos: \n\n";
		
		for (Medicamento medicamento: medicamentos) {
			msg += medicamento.nome + " tem o(s) seguintes ativos " + ativos(medicamento) + "\n";
		}
		
		return msg;
		
	}
	
	public static String ativos(Medicamento medicamento) {
		String msg = "";
		for(int i = 0; i < medicamento.ativos.size(); i++) {
			if(medicamento.ativos.get(i) == 1) {
				msg += "PARACETAMOL ";
			}
			if(medicamento.ativos.get(i) == 2) {
				msg += "CLORFENIRAMINA ";
			}
			if(medicamento.ativos.get(i) == 3)
			msg += "FENILEFRINA";
		}
		return msg;
	}
	
	public static void cadastrar(ArrayList<Medicamento> medicamentos) {
		if(medicamentos.size() >= 500) {
			JOptionPane.showMessageDialog(null, "Memória cheia!");
		} else {
		Medicamento medicamento = new Medicamento();
		medicamento.nome = JOptionPane.showInputDialog("Nome do medicamento: ");
		
		int ativo;
		do {
			ativo = lerAtivos();
			if(ativo != -1) {
			
				medicamento.ativos.add(ativo);
			}
				
		}while(ativo != -1);
		
		
		medicamentos.add(medicamento);
		
		}
	}
	
	public static int lerAtivos() {
		String ativoOpcao = JOptionPane.showInputDialog("Qual o ativo(s) deste medicamento?: (Digite X para sair)\n\n"
				+ "1 - PARACETAMOL\n"
				+ "2 - CLORFENIRAMINA\n"
				+ "3 - FENILEFRINA\n");
		if(ativoOpcao.toUpperCase().equals("X")) {
			return -1;
		} else {
		int ativo = Integer.parseInt(ativoOpcao);
		
		if(ativo < 1 || ativo > 3) {
			return lerAtivos();
		}
		
		return ativo;
		}
		
	}
	
	public static int menu() {
		String mainMenu = "1 - Incluir medicamento\n"
				+ "2 - Listar todos os medicamentos\n"
				+ "3 - Buscar por nome de princípio ativo\n\n"
				+ "4 - Mostrar o percentual de memória livre\n"
				+ "0 - Sair do sistema\n";
		int op = Integer.parseInt(JOptionPane.showInputDialog(mainMenu));
		if(op < 0 || op > 4) {
			return menu();
		}
		return op;
	}
	
}

